# ANIME VANGUARD ALL IN ONE MACRO
Anime vanguard all in one macro is an automation program service that use hotkey to macro. This macro include:
- Auto Challenge
- Bounty
- Boss Rush
- Legend stage (Buu and Lfelt included)
- Raid
- Rift
- Odyssey
- Portal
- Worldline
- Custom config
- Support many unit
- Result sending via Discord Webhook
- Can be controlled with Discord Bot

## 📘 TOPICS
- [How to use](#-how-to-use)
- [Support](#support)

## ✏️ HOW TO USE
### Installation
- [AutoHotkey](https://www.autohotkey.com/download/ahk-v2.exe)
- [Python](https://www.python.org/downloads) for Discord Bot
- [Macro](https://github.com/SalmonDXH/Anime-Vanguard-AIO-Macro/archive/refs/heads/main.zip)

### Steps
**For macro:**
1. Install auto hotkey
2. Run AV_AIO.exe
3. Adjust your team in placement settings
4. Adjust your gamemode settings
5. Adjust Farn settings
6. F2 to start


**For Discord Bot:** 
1. Install Python
2. Run AV_AIO.exe
3. F7 to run Discord Bot

## SUPPORT
- [Discord](https://www.discord.gg/salmon)